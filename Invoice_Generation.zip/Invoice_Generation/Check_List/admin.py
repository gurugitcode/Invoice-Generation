from django.contrib import admin
from . models import Admin_Models
# Register your models here.

@admin.register(Admin_Models)
class Admin_Model_Admin(admin.ModelAdmin):
    list_display=['invoice_number','invoice_date','seller_name','buyer_name','seller_Address','buyer_Address','sellar_phone_no','buyer_phone_no','serial_no','quantity','product','amount','total_amount']
    