function btnsave() {
    Alert()
        // console.log("Save Button Clicked")
        // list_display=['student_name','father_name','dob','address','city','state','pinno','mobailno','email','class_opted','marks','date_enrolled']

    output = "";
    let invoiceno = $("#id_invoice_number").val();
    let invoicedate = $("#id_invoice_date").val();
    let sname = $("#id_seller_name").val();
    let bname = $("#id_buyer_name").val();
    let saddress = $("#id_seller_Address").val();
    let baddress = $("#id_buyer_Address").val();
    let sphone = $("#id_sellar_phone_no").val();
    let bphone = $("#id_buyer_phone_no").val();
    let sno = $("#id_serial_no").val();
    let pid = $("#id_product_id").val();
    let p = $("#id_product").val();
    let qty = $("#id_quantity").val();
    let idamount = $("#id_amount").val();
    let csr = $("input[name=csrfmiddlewaretoken]").val();

    mydata = {
        id_invoice_number: invoiceno,
        id_invoice_date: invoicedate,
        id_seller_name: sname,
        id_buyer_name: bname,
        id_seller_Address: saddress,
        id_buyer_Address: baddress,
        id_sellar_phone_no: sphone,
        id_buyer_phone_no: bphone,
        id_serial_no: sno,
        id_product_id: pid,
        id_quantity: qty,
        id_amount: idamount,
        csrfmiddlewaretoken: csr

    };
    $.ajax({
        url: "{% url 'data' %}",
        method: "POST",
        data: mydata,
        success: function(data) {
            // console.log(data); 
            x = data.student_data
            if (data.status == "Save") {
                $("#msg").text("Form Submitted Successfily");
                $("#msg").show();

                // console.log("Form Submitted Successfily");
                // console.log(data.student_data)


            }
            if (data.status == 0) {
                $("#msg").text("Unable to Form Submitted Successfily");
                $("#msg").show();
                $("#stuid").val();
                $("form")[0].reset();
                // console.log("Unable to save Form");

            }
        }
    })
}
});