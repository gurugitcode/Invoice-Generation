from django import forms
from .models import Admin_Models

class Admin_ModelForm(forms.ModelForm):
    class Meta:
        model=Admin_Models
        fields=['invoice_number','invoice_date','seller_name','buyer_name','seller_Address','buyer_Address','sellar_phone_no','buyer_phone_no','serial_no','quantity','product','amount','total_amount']
        labels={'invoice_number':'Invoice_Number','invoice_date':'Invoice_Date','seller_name':'Seller_Name','buyer_name':'buyer_name','seller_Address':'seller_Address','buyer_Address':'buyer_Address','sellar_phone_no':'sellar_phone_no','buyer_phone_no':'buyer_phone_no','serial_no':'Serial_Number','quantity':'quantity','product':'product','amount':'amount','total_amount':'total_amount'}
        widgets = {'invoice_number':forms.NumberInput(attrs={'class':'form-control','id':'id_invoice_number'}),
        'invoice_date':forms.DateInput(format='%d/%m/%Y',attrs={'class':'form-control','id':'id_invoice_date'}),
        'seller_name':forms.TextInput(attrs={'class':'form-control','id':'id_seller_name'}),
        'buyer_name':forms.TextInput(attrs={'class':'form-control','id':'id_buyer_name'}),
        'seller_Address':forms.TextInput(attrs={'class':'form-control','id':'id_seller_Address'}),
        'buyer_Address':forms.TextInput(attrs={'class':'form-control','id':'id_buyer_Address'}),
        'sellar_phone_no':forms.NumberInput(attrs={'class':'form-control','id':'id_sellar_phone_no'}),
        'buyer_phone_no':forms.NumberInput(attrs={'class':'form-control','id':'id_buyer_phone_no'}),
        'serial_no':forms.NumberInput(attrs={'class':'form-control','id':'id_serial_no'}),
        'quantity':forms.NumberInput(attrs={'class':'form-control','id':'id_product_id'}),
        'product':forms.TextInput(attrs={'class':'form-control','id':'id_product'}),
        'amount':forms.NumberInput(attrs={'class':'form-control','id':'id_quantity'}),
        'total_amount':forms.NumberInput(attrs={'class':'form-control','id':'id_amount'}),
        }