from django.db import models
from django.core.validators import MaxValueValidator

# Create your models here.
class Admin_Models(models.Model):
    invoice_number=models.IntegerField(null=True,blank=True)
    invoice_date=models.DateField(null=True,blank=True)
    seller_name=models.CharField(max_length=100,null=True,blank=True)
    buyer_name=models.CharField(max_length=255,null=True,blank=True)
    seller_Address=models.CharField(max_length=255,null=True,blank=True)
    buyer_Address=models.CharField(max_length=255,null=True,blank=True)
    sellar_phone_no = models.IntegerField(default='+91',null=True,blank=True,validators=[MaxValueValidator(9999999999)])
    buyer_phone_no = models.IntegerField(default='+91',null=True,blank=True,validators=[MaxValueValidator(9999999999)])
    serial_no=models.IntegerField(null=True,blank=True)
    quantity=models.IntegerField(null=True,blank=True)
    product = models.CharField(max_length=255,null=True,blank=True)
    amount=models.IntegerField(null=True,blank=True)
    total_amount=models.FloatField(null=True,blank=True)
