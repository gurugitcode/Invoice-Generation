from django.urls import path
from . import views

urlpatterns = [
    path('',views.Main_View.as_view(),name='main'),
    path('form',views.Admin_View_Form.as_view(),name='Form'),
]
