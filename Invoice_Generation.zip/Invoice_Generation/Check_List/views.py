from django.shortcuts import render
from django.contrib import messages
from django.views import View
from  . models import Admin_Models
from .forms import Admin_ModelForm
from django.http import JsonResponse
# Create your views here.
class Main_View(View):
    template_name="home.html"
    def get(self, request):
        return render(request, self.template_name, context=None, content_type=None, status=None, using=None)


class Admin_View_Form(View):
    template_name="Admin.html"
    def get(self, request):
        # fm=Admin_ModelForm(initial={'amount':'6767'})
        fm=Admin_ModelForm()
        return render(request, self.template_name,{'form':fm})

    def post(self,request):
        if request.method=='POST':
            fm=Admin_ModelForm(request.POST)
            if fm.is_valid():
                try: 
                    # invoicno=[]
                    invoice_number=fm.cleaned_data['invoice_number']
                    # value = request.POST['indata']
                    
                    # invoice_num=str(invoice_numbers)+'/'+str(value)
                    # invoice_number=str(invoice_num)
                    # print(type(invoice_number))
                    # print('value',invoice_number)
                    invoic=fm.cleaned_data['invoice_date']
                    print(invoic)
                    seller=fm.cleaned_data['seller_name']
                    print(type(seller))
                    buyer=fm.cleaned_data['buyer_name']
                    print(buyer)
                    sellera=fm.cleaned_data['seller_Address']
                    print(sellera)
                    buyera=fm.cleaned_data['buyer_Address']
                    print(buyera)
                    s_phone=fm.cleaned_data['sellar_phone_no']
                    print(s_phone)
                    b_phone=fm.cleaned_data['buyer_phone_no']
                    print(b_phone)
                    serial=fm.cleaned_data['serial_no']
                    print(serial)
                    producti=fm.cleaned_data['quantity']
                    print(producti)
                    product=fm.cleaned_data['product']
                    print(product)
                    quantity=fm.cleaned_data['amount']
                    print(quantity)
                    amount=fm.cleaned_data['total_amount']
                    print(amount)
                    reg=Admin_Models(invoice_number=invoice_number,invoice_date=invoic,seller_name=seller,buyer_name=buyer,seller_Address=sellera,buyer_Address=buyera,sellar_phone_no=s_phone,buyer_phone_no=b_phone,serial_no=serial,quantity=producti,product=product,amount=quantity,total_amount=amount)
                    reg.save()
                    fm=Admin_ModelForm()
                    messages.success(request, "Successfully data uplodeed")
                    return render(request, self.template_name,{'form':fm})
                except:
                    messages.success(request, "Successfully data not uplodeed")
                    return render(request, self.template_name,{'form':fm})
               
                # fm=Admin_ModelForm()
                # return render(request, self.template_name,{'form':fm})
