from django.apps import AppConfig


class CheckListConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Check_List'
